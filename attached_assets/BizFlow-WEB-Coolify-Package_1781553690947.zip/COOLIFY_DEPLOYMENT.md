# BizFlow / LaunchFlow Coolify Deployment

This package targets the real production web app:

- Web app: `artifacts/web`
- Web Dockerfile: `artifacts/web/Dockerfile.web`
- API app: `artifacts/api-server`
- API Dockerfile: `artifacts/api-server/Dockerfile.server`
- Database: PostgreSQL 16

## Coolify setup

Use deployment type:

```txt
Docker Compose
```

Public app/service:

```txt
web
```

Public port:

```txt
80
```

## Required environment variables

Set these in Coolify:

```env
POSTGRES_PASSWORD=strong_random_password
VITE_CLERK_PUBLISHABLE_KEY=pk_live_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
CLERK_SECRET_KEY=sk_live_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
SESSION_SECRET=long_random_64_char_plus_secret
VITE_CLERK_PROXY_URL=https://YOUR-DOMAIN/api/__clerk
```

Optional:

```env
DEFAULT_OBJECT_STORAGE_BUCKET_ID=
PRIVATE_OBJECT_DIR=
PUBLIC_OBJECT_SEARCH_PATHS=
WEB_PORT=80
```

## Health checks

API:

```txt
/api/healthz
```

Web:

```txt
/
```

## Important

Do not deploy `artifacts/mockup-sandbox`. That is not the production web app.

Use `artifacts/web` only.
